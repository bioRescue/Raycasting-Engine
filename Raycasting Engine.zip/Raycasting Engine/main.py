import pygame
import math

pygame.init()

WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("РЭЙКЭСТИНГ")

FOV = math.pi / 3
NUM_RAYS = 100
MAX_DEPTH = 800
SCALE = WIDTH // NUM_RAYS
SPEED = 0.1

MAP = [
    "1111111111111111",
    "1000000000000001",
    "1000001000000001",
    "1000001000000001",
    "1000000000000001",
    "1111111111111111"
]

player_x, player_y = 299, 197
player_angle = 0

def cast_ray(angle):
    sin_a = math.sin(angle)
    cos_a = math.cos(angle)
    ray_x, ray_y = player_x, player_y

    for depth in range(MAX_DEPTH):
        ray_x += cos_a
        ray_y += sin_a

        map_x = int(ray_x // 40)
        map_y = int(ray_y // 40)

        if map_x < 0 or map_x >= len(MAP[0]) or map_y < 0 or map_y >= len(MAP):
            return MAX_DEPTH

        if MAP[map_y][map_x] == '1':
            return depth

    return MAX_DEPTH

def move_camera(keys):
    global player_x, player_y, player_angle

    if keys[pygame.K_w]:
        player_x += math.cos(player_angle) * SPEED
        player_y += math.sin(player_angle) * SPEED
    if keys[pygame.K_s]:
        player_x -= math.cos(player_angle) * SPEED
        player_y -= math.sin(player_angle) * SPEED

    if keys[pygame.K_a]:
        player_angle -= 0.05
    if keys[pygame.K_d]:
        player_angle += 0.05

running = True
while running:
    screen.fill((0, 0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    keys = pygame.key.get_pressed()
    move_camera(keys)

    for ray in range(NUM_RAYS):
        angle = player_angle - FOV / 2 + (ray / NUM_RAYS) * FOV
        depth = cast_ray(angle)

        if depth == MAX_DEPTH:
            continue

        wall_height = HEIGHT / (depth + 0.0001)

        pygame.draw.rect(screen, (255, 0, 0), (ray * SCALE, HEIGHT // 2 - wall_height // 2, SCALE, wall_height))

    pygame.display.flip()

pygame.quit()
